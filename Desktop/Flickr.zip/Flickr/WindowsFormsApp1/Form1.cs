﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Xml;
using System.Xml.Linq;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        static WebClient client = new WebClient();
        static List<dynamic> list;
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string search = txtsearch.Text.Replace(' ', ',');
            string str = client.DownloadString(new Uri($"https://api.flickr.com/services/rest/?method=flickr.photos.search&tags={search}&text={search}&tag_mode=all&api_key=8d5667b773fcf3198db0768dd1ebc8f9"));
            XDocument doc = XDocument.Parse(str);
            var photos = from photo in doc.Descendants("photo")
                         let id = photo.Attribute("id").Value
                         let title = photo.Attribute("title").Value
                         let secret = photo.Attribute("secret").Value
                         let server = photo.Attribute("server").Value
                         let farm = photo.Attribute("farm").Value
                         select new
                         {
                             Title = title,
                             uri = new Uri($"https://farm{farm}.staticflickr.com/{server}/{id}_{secret}.jpg")
                         };
            list = photos.ToList<dynamic>();
            listBox.DataSource = list.Select(x=> x.Title).ToList();
            
        }

        private async void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            WebClient imageClient = new WebClient();
            byte[] imageBytes = await imageClient.DownloadDataTaskAsync(list[listBox.SelectedIndex].uri);
            pictureBox1.Image = new Bitmap(new MemoryStream(imageBytes));
        }
    }
}
