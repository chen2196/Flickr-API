﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Net;
using System.Net.Http;

namespace ConsoleApp1
{
    class Program
    {
        static WebClient client = new WebClient();
        static void Main(string[] args)
        {
            Runasync();
        }
        static async void Runasync()
        {

            string str = client.DownloadStringTaskAsync(new Uri("https://api.flickr.com/services/rest/?method=flickr.photos.search&tags=football&api_key=8d5667b773fcf3198db0768dd1ebc8f9")).Result;
            XDocument doc = XDocument.Parse(str);
            var photos = from photo in doc.Descendants("photo")
                         let id = photo.Attribute("id").Value
                         let title = photo.Attribute("title").Value
                         let secret = photo.Attribute("secret").Value
                         let server = photo.Attribute("server").Value
                         let farm = photo.Attribute("farm").Value
                         select new
                         {
                             Title = title,
                             uri = new Uri($"https://farm{farm}.staticflickr.com/{server}/{id}_{secret}.jpg")
                         };
            List<dynamic> list = photos.ToList<dynamic>();
            Console.WriteLine(doc);
 
        }
    }
}
