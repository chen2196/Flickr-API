﻿   using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using System.Windows.Forms;
   using System.Xml.Linq;
 
   namespace FlickrViewer
   {
      public partial class FlickrViewerForm : Form
      {
         // Use your Flickr API key here--you can get one at:
         // http://www.flickr.com/services/apps/create/apply
         private const string KEY = "2592b996090515cfa7bd4f579d9c45c2cb6e8f7fbccf6a95";

        // object used to invoke Flickr web service      
        private WebClient flickrClient = new WebClient();
        

         Task<string> flickrTask = null; // Task<string> that queries Flickr
         private List<KeyValuePair<string, string>> flickrPhotos;
        public FlickrViewerForm()
         {
            InitializeComponent();
         } // end constructor
 
         // initiate asynchronous Flickr search query;
         // display results when query completes
         // end method searchButton_Click
 
        // display selected image
        private async void imagesListBox_SelectedIndexChanged(
           object sender, EventArgs e)
        {
           if (imagesListBox.SelectedItem != null )
           {
                string selectedURL = flickrPhotos[imagesListBox.SelectedIndex].Value;
 
              // use WebClient to get selected image's bytes asynchronously 
              WebClient imageClient = new WebClient();                     
              byte[] imageBytes = await imageClient.DownloadDataTaskAsync(
                 selectedURL);                                            
 
              // display downloaded image in pictureBox                  
              MemoryStream memoryStream = new MemoryStream(imageBytes);
              pictureBox.Image = Image.FromStream(memoryStream );       
           } // end if
        } // end method imagesListBox_SelectedIndexChanged

        private async void searchButton_Click_1(object sender, EventArgs e)
        {
            // if flickrTask already running, prompt user
            if (flickrTask != null &&
                flickrTask.Status != TaskStatus.RanToCompletion)
            {
                var result = MessageBox.Show(
                   "Cancel the current Flickr search?",
                   "Are you sure?", MessageBoxButtons.YesNo,
                   MessageBoxIcon.Question);

                // determine whether user wants to cancel prior search
                if (result == DialogResult.No)
                    return;
                else
                    flickrClient.CancelAsync(); // cancel current search 
            } // end if

            // Flickr's web service URL for searches                         
            var flickrURL = string.Format("http://api.flickr.com/services" +
               "/rest/?method=flickr.photos.search&api_key={0}&tags={1}" +
               "&tag_mode=all&per_page=100&privacy_filter=1", KEY,
               inputTextBox.Text.Replace(" ", ","));

            imagesListBox.DataSource = null; // remove prior data source
            imagesListBox.Items.Clear(); // clear imagesListBox
            pictureBox.Image = null; // clear pictureBox
            imagesListBox.Items.Add("Loading..."); // display Loading...

            try
            {
                // invoke Flickr web service to search Flick with user's tags 
                flickrTask =
                   flickrClient.DownloadStringTaskAsync(flickrURL);

                // await flickrTask then parse results with XDocument and LINQ 
                XDocument flickrXML = XDocument.Parse(await flickrTask);

                // gather information on all photos
                flickrPhotos = (List<KeyValuePair<string, string>>)
                from photo in flickrXML.Descendants("photo")
                let id = photo.Attribute("id").Value
                let title = photo.Attribute("title").Value
                let secret = photo.Attribute("secret").Value
                let server = photo.Attribute("server").Value
                let farm = photo.Attribute("farm").Value
                select new KeyValuePair<string, string>
                (
                    title,
                    string.Format(
                      "http://farm{0}.staticflickr.com/{1}/{2}_{3}.jpg",
                      farm, server, id, secret)
                );

                imagesListBox.Items.Clear(); // clear imagesListBox
                                             // set ListBox properties only if results were found
                if (flickrPhotos.Any())
                {
                    imagesListBox.DataSource = flickrPhotos.ToList();
                    imagesListBox.DisplayMember = "Title";
                } // end if
                else // no matches were found
                    imagesListBox.Items.Add("No matches");
            } // end try
            catch (Exception a)
            {
                if (flickrTask.Status == TaskStatus.Faulted)
                    MessageBox.Show(a.Message,
                      "Flickr Error", MessageBoxButtons.OK,
                      MessageBoxIcon.Error);
                imagesListBox.Items.Clear(); // clear imagesListBox
                imagesListBox.Items.Add("Error occurred");
            }
        }
    } // end class FlickrViewerForm
  } // end namespace FlickrViewer
